package com.yicu.yichujifa;

import android.content.Context;

public class Main {
    public native static void init(Context context);
}
