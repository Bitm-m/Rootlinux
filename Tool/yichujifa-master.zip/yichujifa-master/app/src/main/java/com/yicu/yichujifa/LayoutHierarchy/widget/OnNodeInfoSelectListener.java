package com.yicu.yichujifa.LayoutHierarchy.widget;


public interface OnNodeInfoSelectListener {
    void onNodeSelect(NodeInfo info);

}