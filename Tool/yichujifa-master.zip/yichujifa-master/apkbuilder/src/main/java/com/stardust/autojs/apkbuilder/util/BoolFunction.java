package com.stardust.autojs.apkbuilder.util;

/**
 * Created by Stardust on 2017/10/23.
 */

public interface BoolFunction<T> {

    boolean accept(T t);
}
